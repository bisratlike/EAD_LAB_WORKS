// Constants
const API_BASE_URL = "http://localhost:8090/api";
const BOOKMARKS_ENDPOINT = `${API_BASE_URL}/bookmarks`;

// DOM Elements
const bookmarksGrid = document.getElementById("bookmarksGrid");
const loadingSpinner = document.getElementById("loadingSpinner");
const errorMessage = document.getElementById("errorMessage");
const noBookmarksMessage = document.getElementById("noBookmarksMessage");

// Fetch bookmarks
async function fetchBookmarks() {
  try {
    showLoading(true);
    const token = localStorage.getItem("authToken");
    
    const response = await fetch(BOOKMARKS_ENDPOINT, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (!response.ok) throw new Error("Failed to fetch bookmarks");
    return await response.json();
  } catch (error) {
    showError(error.message || "Failed to load bookmarks");
    return [];
  } finally {
    showLoading(false);
  }
}

// Render bookmarks
function renderBookmarks(bookmarks) {
  bookmarksGrid.innerHTML = "";

  if (bookmarks.length === 0) {
    noBookmarksMessage.classList.remove("hidden");
    return;
  }

  bookmarks.forEach(bookmark => {
    const bookmarkCard = document.createElement("div");
    bookmarkCard.className = "bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow";
    bookmarkCard.innerHTML = `
      <div class="relative h-48">
        <img src="${bookmark.item.images?.[0] || 'placeholder.jpg'}" 
             alt="${bookmark.item.title}" 
             class="w-full h-full object-cover">
      </div>
      <div class="p-4">
        <h3 class="font-semibold text-lg truncate">${bookmark.item.title}</h3>
        <p class="text-gray-600 text-sm mt-2 line-clamp-2">${bookmark.item.description}</p>
        <div class="mt-4 flex justify-between items-center">
          <span class="text-blue-600 font-bold">ETB ${bookmark.item.price}/day</span>
          <button onclick="removeBookmark('${bookmark.id}')" class="text-red-400 hover:text-red-600">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </div>
    `;
    bookmarkCard.addEventListener("click", () => viewItemDetails(bookmark.item.id));
    bookmarksGrid.appendChild(bookmarkCard);
  });
}

// Remove bookmark
async function removeBookmark(bookmarkId) {
  try {
    const token = localStorage.getItem("authToken");
    const response = await fetch(`${BOOKMARKS_ENDPOINT}/${bookmarkId}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${token}` }
    });

    if (!response.ok) throw new Error("Failed to remove bookmark");
    await loadBookmarks(); // Refresh list
  } catch (error) {
    showError(error.message || "Failed to remove bookmark");
  }
}

// Load bookmarks
async function loadBookmarks() {
  const bookmarks = await fetchBookmarks();
  renderBookmarks(bookmarks);
}

// Helpers
function showLoading(show) {
  loadingSpinner.classList.toggle("hidden", !show);
  bookmarksGrid.classList.toggle("hidden", show);
}

function showError(message) {
  errorMessage.textContent = message;
  errorMessage.classList.remove("hidden");
  setTimeout(() => errorMessage.classList.add("hidden"), 3000);
}

// Initialize
document.addEventListener("DOMContentLoaded", () => {
  if (!localStorage.getItem("authToken")) {
    window.location.href = "../login.html";
    return;
  }
  loadBookmarks();
});