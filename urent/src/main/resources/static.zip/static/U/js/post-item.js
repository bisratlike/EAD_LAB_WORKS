// Constants
const API_BASE_URL = "http://localhost:8090/api";
const ITEMS_ENDPOINT = `${API_BASE_URL}/items`;

// DOM Elements
const postItemForm = document.getElementById("postItemForm");
const imageInput = document.getElementById("images");
const photoPreviewsContainer = document.getElementById("photoPreviewsContainer");
const loadingSpinner = document.getElementById("loadingSpinner");
const errorMessage = document.getElementById("error-message");
const successMessage = document.getElementById("success-message");

// Handle image preview for a single image
imageInput.addEventListener("change", (event) => {
  photoPreviewsContainer.innerHTML = ""; // Clear existing previews
  const file = event.target.files[0]; // Get the first file

  if (file && file.type.startsWith("image/")) {
    const reader = new FileReader();
/*************  ✨ Codeium Command ⭐  *************/
/**
 * Handles the loading of an image file and creates a preview element.
 * The preview element includes the image and a remove button that allows
 * the user to delete the preview. The image is displayed as a thumbnail
 * with specific styling, and the remove button appears when hovering over
 * the preview.
 *
/******  03ef458e-2e6e-4677-801a-6f969c42003b  *******/
    reader.onload = (e) => {
      const previewDiv = document.createElement("div");
      previewDiv.className = "relative group";

      const img = document.createElement("img");
      img.src = e.target.result;
      img.className = "w-full h-48 object-cover rounded-lg";

      // Add remove button
      const removeButton = document.createElement("button");
      removeButton.className =
        "absolute top-2 right-2 bg-red-500 text-white rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity";
      removeButton.innerHTML = '<i class="fas fa-times"></i>';
      removeButton.onclick = () => previewDiv.remove();

      previewDiv.appendChild(img);
      previewDiv.appendChild(removeButton);
      photoPreviewsContainer.appendChild(previewDiv);
    };
    reader.readAsDataURL(file);
  } else {
    showError("Please upload a valid image file.");
  }
});
// Handle form submission
postItemForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  // Check if user is logged in
  const token = localStorage.getItem('authToken');
  if (!token) {
      showError("You must be logged in to post an item.");
      return;
  }

  // Show loading spinner
  loadingSpinner.style.display = "block";

  try {
      // Get form data
      const formData = new FormData(postItemForm);
      formData.append('image', imageInput.files[0]); // Append the first image

      // Send request to API
      const response = await fetch(ITEMS_ENDPOINT, {
          method: "POST",
          headers: {
              'Authorization': `Bearer ${token}`
          },
          body: formData,
      });

      // Check if response is OK
      if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
      }

      // Get response data
      const responseData = await response.json();

      // Show success message
      successMessage.style.display = "block";
      successMessage.textContent = "Item posted successfully!";

      // Hide loading spinner
      loadingSpinner.style.display = "none";

      // Reset form
      postItemForm.reset();
  } catch (error) {
      // Show error message
      errorMessage.style.display = "block";
      errorMessage.textContent = error.message;

      // Hide loading spinner
      loadingSpinner.style.display = "none";
  }
});