// Global state
let bookmarks = [];
let filteredBookmarks = [];

// UI Elements
const searchInput = document.getElementById('searchBookmarks');
const sortSelect = document.getElementById('sortBookmarks');

// Function to show loading state
function showLoading() {
  document.getElementById("loadingSpinner").classList.remove("hidden");
}

// Function to hide loading state
function hideLoading() {
  document.getElementById("loadingSpinner").classList.add("hidden");
}

// Function to show error message
function showError(message) {
  const errorDiv = document.getElementById("error-message");
  errorDiv.querySelector("span").textContent = message;
  errorDiv.classList.remove("hidden");
  setTimeout(() => {
    errorDiv.classList.add("hidden");
  }, 5000);
}

// Function to show success message
function showSuccess(message) {
  const successDiv = document.getElementById("success-message");
  successDiv.querySelector("span").textContent = message;
  successDiv.classList.remove("hidden");
  setTimeout(() => {
    successDiv.classList.add("hidden");
  }, 5000);
}

// Function to format price
function formatPrice(price) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(price);
}

// Function to render a single bookmark card
function renderBookmarkCard(item) {
  return `
    <div class="bookmark-card bg-white shadow-lg rounded-xl overflow-hidden">
      <div class="relative group">
        <img
          src="${item.imageUrl || 'placeholder.jpg'}"
          alt="${item.title}"
          class="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110"
          onerror="this.src='placeholder.jpg'"
        />
        <div class="absolute inset-0 bg-black bg-opacity-40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <a href="item-details.html?id=${item.itemId}" 
            class="bg-white text-blue-600 px-4 py-2 rounded-lg font-medium hover:bg-blue-50 transition-colors">
            View Details
          </a>
        </div>
      </div>
      
      <div class="p-4">
        <div class="flex justify-between items-start mb-2">
          <h3 class="text-lg font-semibold text-gray-900 truncate">${item.title}</h3>
          <span class="text-lg font-bold text-blue-600">${formatPrice(item.price)}<span class="text-sm text-gray-500">/day</span></span>
        </div>
        
        <div class="flex items-center mb-3">
          <span class="px-2 py-1 text-sm rounded-full ${
            item.available 
              ? 'bg-green-100 text-green-800' 
              : 'bg-red-100 text-red-800'
          }">
            ${item.available ? 'Available' : 'Not Available'}
          </span>
        </div>

        <div class="flex items-center justify-between">
          <div class="flex items-center">
            <img 
              src="${item.ownerProfilePicture || 'default-avatar.jpg'}" 
              alt="${item.ownerName}"
              class="w-8 h-8 rounded-full object-cover mr-2"
              onerror="this.src='default-avatar.jpg'"
            />
            <span class="text-sm text-gray-600">${item.ownerName}</span>
          </div>
          <button
            onclick="removeBookmark('${item.id}')"
            class="text-red-600 hover:text-red-800 transition-colors"
            title="Remove from bookmarks"
          >
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </div>
    </div>
  `;
}

// Function to render bookmarks grid
function renderBookmarksGrid() {
  const grid = document.getElementById("bookmarksGrid");
  const noBookmarksMessage = document.getElementById("noBookmarksMessage");

  if (filteredBookmarks.length === 0) {
    grid.classList.add("hidden");
    noBookmarksMessage.classList.remove("hidden");
    return;
  }

  grid.classList.remove("hidden");
  noBookmarksMessage.classList.add("hidden");
  
  grid.innerHTML = filteredBookmarks.map(renderBookmarkCard).join('');
}

// Function to filter and sort bookmarks
function filterAndSortBookmarks() {
  const searchTerm = searchInput.value.toLowerCase();
  const sortBy = sortSelect.value;

  // Filter bookmarks
  filteredBookmarks = bookmarks.filter(bookmark => 
    bookmark.title.toLowerCase().includes(searchTerm) ||
    bookmark.ownerName.toLowerCase().includes(searchTerm)
  );

  // Sort bookmarks
  filteredBookmarks.sort((a, b) => {
    switch (sortBy) {
      case 'newest':
        return new Date(b.createdAt) - new Date(a.createdAt);
      case 'oldest':
        return new Date(a.createdAt) - new Date(b.createdAt);
      case 'priceHigh':
        return b.price - a.price;
      case 'priceLow':
        return a.price - b.price;
      default:
        return 0;
    }
  });

  renderBookmarksGrid();
}

// Function to fetch bookmarks from API
async function fetchBookmarks() {
  try {
    showLoading();
    const response = await fetch("/api/bookmarks", {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${getToken()}`,
        "Content-Type": "application/json"
      }
    });

    if (!response.ok) {
      throw new Error("Failed to fetch bookmarks");
    }

    bookmarks = await response.json();
    filteredBookmarks = [...bookmarks];
    filterAndSortBookmarks();
  } catch (error) {
    console.error("Error fetching bookmarks:", error);
    showError("Failed to load bookmarks. Please try again later.");
  } finally {
    hideLoading();
  }
}

// Function to remove a bookmark
async function removeBookmark(bookmarkId) {
  try {
    showLoading();
    const response = await fetch(`/api/bookmarks/${bookmarkId}`, {
      method: "DELETE",
      headers: {
        "Authorization": `Bearer ${getToken()}`
      }
    });

    if (!response.ok) {
      throw new Error("Failed to remove bookmark");
    }

    showSuccess("Bookmark removed successfully");
    
    // Remove from local state and re-render
    bookmarks = bookmarks.filter(b => b.id !== bookmarkId);
    filterAndSortBookmarks();
  } catch (error) {
    console.error("Error removing bookmark:", error);
    showError("Failed to remove bookmark. Please try again later.");
  } finally {
    hideLoading();
  }
}

// Event listeners
searchInput.addEventListener('input', filterAndSortBookmarks);
sortSelect.addEventListener('change', filterAndSortBookmarks);

// Initialize page
document.addEventListener("DOMContentLoaded", () => {
  // Check authentication
  const userData = localStorage.getItem('user');
  if (!userData) {
      window.location.href = '../login.html';
      throw new Error('User data not found. Please log in again.');
  }

  const user = JSON.parse(userData);
  if (!user || !user.id) {
      localStorage.removeItem('user');
  }

  if (!isAuthenticated()) {
    window.location.href = "login.html";
    return;
  }
  fetchBookmarks();
});
