// DOM Elements
const messageForm = document.getElementById('messageForm');
const messageInput = document.getElementById('messageInput');
const chatMessages = document.getElementById('chatMessages');
const connectingElement = document.getElementById('connecting');
const loginPrompt = document.getElementById('loginPrompt');
const chatContainer = document.getElementById('chatContainer');

let stompClient = null;
let userId = null;

// Initialize WebSocket connection
function initializeWebSocket() {
    const socket = new SockJS('http://localhost:8090/ws-chat');
    stompClient = Stomp.over(socket);
    
    // Connect to WebSocket
    stompClient.connect({}, (frame) => {
        console.log('Connected to WebSocket');
        
        // Subscribe to public chat channel
        stompClient.subscribe('/topic/public', (message) => {
            const receivedMessage = JSON.parse(message.body);
            console.log("Received:", receivedMessage);
            displayMessage(receivedMessage);
        });

        // Hide connecting element and show chat
        connectingElement.classList.add('hidden');
        chatContainer.classList.remove('hidden');

        // Send join message
        sendMessage('Joined the chat', 'JOIN');
    }, onError);
}

// Send message function
function sendMessage(content, type = 'CHAT') {
    if (!stompClient) {
        console.error('WebSocket connection not established');
        return;
    }

    const token = localStorage.getItem('token');
    if (!token && type === 'CHAT') {
        showLoginPrompt();
        return;
    }

    // Get user ID from token
    if (!userId) {
        const tokenData = parseJwt(token);
        userId = tokenData.sub || 'anonymous';
    }

    const chatMessage = {
        content: content,
        senderId: userId,
        type: type
    };

    stompClient.send("/app/chat.send", {}, JSON.stringify(chatMessage));
}

// Display received message
function displayMessage(message) {
    const messageElement = createMessageElement(message);
    chatMessages.appendChild(messageElement);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Create message element
function createMessageElement(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'mb-4';

    const isMyMessage = message.senderId === userId;
    const messageContentClass = isMyMessage 
        ? 'bg-blue-500 text-white rounded-lg py-2 px-4 max-w-xs ml-auto' 
        : 'bg-gray-200 rounded-lg py-2 px-4 max-w-xs';

    if (message.type === 'JOIN' || message.type === 'LEAVE') {
        messageDiv.innerHTML = `
            <div class="text-center text-gray-500 text-sm">
                ${message.content}
            </div>
        `;
    } else {
        messageDiv.innerHTML = `
            <div class="flex flex-col ${isMyMessage ? 'items-end' : 'items-start'}">
                <div class="text-xs text-gray-500 mb-1">User ${message.senderId}</div>
                <div class="${messageContentClass}">
                    ${message.content}
                </div>
            </div>
        `;
    }

    return messageDiv;
}

// Error handling
function onError(error) {
    console.error('WebSocket Error:', error);
    connectingElement.textContent = 'Could not connect to WebSocket server. Please refresh this page to try again!';
    connectingElement.classList.add('text-red-500');
}

// UI Helper functions
function showLoginPrompt() {
    loginPrompt.classList.remove('hidden');
    chatContainer.classList.add('hidden');
}

function hideLoginPrompt() {
    loginPrompt.classList.add('hidden');
    chatContainer.classList.remove('hidden');
}

// JWT Helper
function parseJwt(token) {
    try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        return JSON.parse(window.atob(base64));
    } catch (e) {
        return {};
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    const token = localStorage.getItem('token');
    if (!token) {
        showLoginPrompt();
    } else {
        hideLoginPrompt();
        initializeWebSocket();
    }
});

messageForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const content = messageInput.value.trim();
    if (content) {
        sendMessage(content);
        messageInput.value = '';
    }
});

messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        const content = messageInput.value.trim();
        if (content) {
            sendMessage(content);
            messageInput.value = '';
        }
    }
});

// Handle page unload
window.addEventListener('beforeunload', () => {
    if (stompClient) {
        sendMessage('Left the chat', 'LEAVE');
        stompClient.disconnect();
    }
});
