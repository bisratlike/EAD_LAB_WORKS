// Items page functionality
let currentPage = 0;
let isLoading = false;
let hasMoreItems = true;
let currentSearchQuery = '';
let itemPhotos = [];

// Load items
async function loadItems(page = 0, search = '') {
    try {
        if (isLoading || (!hasMoreItems && page > 0)) return;
        
        isLoading = true;
        toggleLoadingSpinner(true);
        
        const response = await fetch(
            `${API_URL}/items?page=${page}&size=12${search ? `&query=${encodeURIComponent(search)}` : ''}`,
            {
                headers: {
                    'Authorization': `Bearer ${getAuthToken()}`
                }
            }
        );

        if (!response.ok) {
            throw new Error('Failed to load items');
        }

        const items = await response.json();
        
        if (page === 0) {
            clearItems();
        }
        
        if (items.length < 12) {
            hasMoreItems = false;
        }
        
        renderItems(items);
        currentPage = page;
    } catch (error) {
        showError('Failed to load items. Please try again later.');
        console.error('Items loading error:', error);
    } finally {
        isLoading = false;
        toggleLoadingSpinner(false);
        toggleNoItemsMessage(!document.getElementById('itemsGrid').children.length);
    }
}

// Clear items grid
function clearItems() {
    const grid = document.getElementById('itemsGrid');
    grid.innerHTML = '';
}

// Toggle loading spinner
function toggleLoadingSpinner(show) {
    document.getElementById('loadingSpinner').classList.toggle('hidden', !show);
}

// Toggle no items message
function toggleNoItemsMessage(show) {
    document.getElementById('noItemsMessage').classList.toggle('hidden', !show);
}

// Render items in grid
function renderItems(items) {
    const grid = document.getElementById('itemsGrid');
    
    items.forEach(item => {
        const itemCard = createItemCard(item);
        grid.appendChild(itemCard);
    });
}

// Create item card
function createItemCard(item) {
    const card = document.createElement('div');
    card.className = 'bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105';
    
    // Handle both single image and photos array
    const imageUrl = item.photos && item.photos.length > 0 
        ? item.photos[0] 
        : (item.image 
            ? item.image 
            : 'https://via.placeholder.com/300x200?text=No+Image');
    
    card.innerHTML = `
        <div class="relative pb-2/3">
            <img src="${imageUrl}" alt="${item.title}" class="absolute h-48 w-full object-cover">
        </div>
        <div class="p-4">
            <div class="flex justify-between items-start">
                <h3 class="text-lg font-semibold text-gray-900">${item.title}</h3>
                <p class="text-lg font-bold text-blue-600">$${item.price.toFixed(2)}/day</p>
            </div>
            <p class="mt-2 text-gray-600 text-sm line-clamp-2">${item.description}</p>
            <div class="mt-4 flex justify-between items-center">
                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    item.availability === 'AVAILABLE' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                }">
                    ${item.availability}
                </span>
                <div class="flex space-x-2">
                    <button
                        onclick="toggleBookmark('${item.id}')"
                        class="text-gray-400 hover:text-blue-500 transition-colors"
                        title="Bookmark"
                    >
                        <i class="fas fa-bookmark"></i>
                    </button>
                    <button
                        onclick="showItemDetails('${item.id}')"
                        class="text-gray-400 hover:text-blue-500 transition-colors"
                        title="View Details"
                    >
                        <i class="fas fa-info-circle"></i>
                    </button>
                    ${item.owner ? `
                        <button
                            onclick="editItem('${item.id}')"
                            class="text-gray-400 hover:text-blue-500 transition-colors"
                            title="Edit"
                        >
                            <i class="fas fa-edit"></i>
                        </button>
                        <button
                            onclick="deleteItem('${item.id}')"
                            class="text-gray-400 hover:text-red-500 transition-colors"
                            title="Delete"
                        >
                            <i class="fas fa-trash"></i>
                        </button>
                    ` : ''}
                </div>
            </div>
        </div>
    `;
    
    return card;
}

// Handle file input change
function handlePhotoUpload(event) {
    const files = event.target.files;
    itemPhotos = [];
    
    Array.from(files).forEach(file => {
        if (!file.type.startsWith('image/')) {
            showError('Please select only image files.');
            return;
        }
        
        if (file.size > 5 * 1024 * 1024) {
            showError('Each image must be less than 5MB.');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = (e) => {
            itemPhotos.push(e.target.result);
        };
        reader.readAsDataURL(file);
    });
}

// Create new item
async function createItem(itemData) {
    try {
        const response = await fetch(`${API_URL}/items`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${getAuthToken()}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(itemData)
        });

        if (!response.ok) {
            throw new Error('Failed to create item');
        }

        const newItem = await response.json();
        showSuccess('Item created successfully!');
        closeNewItemModal();
        loadItems(0, currentSearchQuery);
    } catch (error) {
        showError('Failed to create item. Please try again.');
        console.error('Item creation error:', error);
    }
}

// Delete item
async function deleteItem(itemId) {
    if (!confirm('Are you sure you want to delete this item?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/items/${itemId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${getAuthToken()}`
            }
        });

        if (!response.ok) {
            throw new Error('Failed to delete item');
        }

        showSuccess('Item deleted successfully!');
        loadItems(0, currentSearchQuery);
    } catch (error) {
        showError('Failed to delete item. Please try again.');
        console.error('Item deletion error:', error);
    }
}

// Toggle bookmark
async function toggleBookmark(itemId) {
    try {
        const response = await fetch(`${API_URL}/bookmarks/${itemId}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${getAuthToken()}`
            }
        });

        if (!response.ok) {
            throw new Error('Failed to toggle bookmark');
        }

        showSuccess('Bookmark updated!');
    } catch (error) {
        showError('Failed to update bookmark. Please try again.');
        console.error('Bookmark error:', error);
    }
}

// Modal functions
function openNewItemModal() {
    document.getElementById('newItemModal').classList.remove('hidden');
}

function closeNewItemModal() {
    document.getElementById('newItemModal').classList.add('hidden');
    document.getElementById('newItemForm').reset();
    itemPhotos = [];
}

// Handle form submission
async function handleNewItemSubmit(event) {
    event.preventDefault();
    
    const form = event.target;
    const submitButton = form.querySelector('button[type="submit"]');
    submitButton.setAttribute('data-original-text', submitButton.innerHTML);
    
    try {
        setLoading(true, submitButton);
        
        const itemData = {
            title: document.getElementById('title').value,
            description: document.getElementById('description').value,
            price: parseFloat(document.getElementById('price').value),
            photos: itemPhotos,
            availability: document.getElementById('availability').value
        };

        await createItem(itemData);
    } catch (error) {
        showError(error.message || 'Failed to create item');
    } finally {
        setLoading(false, submitButton);
    }
}

// Edit item functionality
function openEditModal(itemId) {
    const modal = document.getElementById('editItemModal');
    modal.classList.remove('hidden');
    
    // Fetch item details
    fetch(`http://localhost:8090/api/items/${itemId}`, {
        headers: {
            'Authorization': getJwtToken()
        }
    })
    .then(response => response.json())
    .then(item => {
        document.getElementById('editItemId').value = item.id;
        document.getElementById('editTitle').value = item.title;
        document.getElementById('editDescription').value = item.description;
        document.getElementById('editPrice').value = item.price;
        document.getElementById('editAvailability').value = item.availability;
        document.getElementById('editPreviewImage').src = item.image || 'https://via.placeholder.com/150';
    })
    .catch(error => {
        console.error('Error fetching item details:', error);
        showError('Failed to load item details');
    });
}

function closeEditModal() {
    const modal = document.getElementById('editItemModal');
    modal.classList.add('hidden');
}

// Handle edit form submission
document.getElementById('editItemForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const itemId = document.getElementById('editItemId').value;
    const formData = new FormData();
    
    formData.append('title', document.getElementById('editTitle').value);
    formData.append('description', document.getElementById('editDescription').value);
    formData.append('price', document.getElementById('editPrice').value);
    formData.append('availability', document.getElementById('editAvailability').value);
    
    const imageFile = document.getElementById('editImage').files[0];
    if (imageFile) {
        formData.append('image', imageFile);
    }
    
    fetch(`http://localhost:8090/api/items/${itemId}`, {
        method: 'PUT',
        headers: {
            'Authorization': getJwtToken()
        },
        body: formData
    })
    .then(response => {
        if (!response.ok) throw new Error('Failed to update item');
        showSuccess('Item updated successfully');
        closeEditModal();
        loadItems(true); // Reload items
    })
    .catch(error => {
        console.error('Error updating item:', error);
        showError('Failed to update item');
    });
});

// Preview image before upload
document.getElementById('editImage').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('editPreviewImage').src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
});

// Load item details
async function loadItemDetails(itemId) {
    // Check authentication
    const userData = localStorage.getItem('user');
    if (!userData) {
        window.location.href = '../login.html';
        throw new Error('User data not found. Please log in again.');
    }

    const user = JSON.parse(userData);
    if (!user || !user.id) {
        localStorage.removeItem('user');
    }

    try {
        toggleLoadingSpinner(true);
        
        const [itemResponse, ownerResponse] = await Promise.all([
            fetch(`${API_URL}/items/${itemId}`, {
                headers: {
                    'Authorization': `Bearer ${getAuthToken()}`
                }
            }),
            fetch(`${API_URL}/items/${itemId}/owner`, {
                headers: {
                    'Authorization': `Bearer ${getAuthToken()}`
                }
            })
        ]);

        if (!itemResponse.ok || !ownerResponse.ok) {
            throw new Error('Failed to load item details');
        }

        const item = await itemResponse.json();
        const owner = await ownerResponse.json();
        
        // Update item details
        document.getElementById('itemTitle').textContent = item.title;
        document.getElementById('itemDescription').textContent = item.description;
        document.getElementById('itemPrice').textContent = `$${item.price.toFixed(2)}/day`;
        
        // Set availability badge
        const availabilityBadge = document.getElementById('itemAvailability');
        availabilityBadge.textContent = item.availability;
        availabilityBadge.className = `px-3 py-1 rounded-full text-sm font-semibold ${
            item.availability === 'AVAILABLE' 
                ? 'bg-green-100 text-green-800' 
                : 'bg-red-100 text-red-800'
        }`;

        // Update images
        const mainImage = document.getElementById('mainImage');
        const imageGallery = document.getElementById('imageGallery');
        
        if (item.photos && item.photos.length > 0) {
            mainImage.src = item.photos[0];
            mainImage.alt = item.title;
            
            imageGallery.innerHTML = item.photos.map((photo, index) => `
                <img src="${photo}" 
                     alt="${item.title} - Photo ${index + 1}" 
                     class="w-full h-20 object-cover rounded cursor-pointer"
                     onclick="updateMainImage('${photo}')">
            `).join('');
        } else {
            mainImage.src = 'https://via.placeholder.com/600x400?text=No+Image';
            mainImage.alt = 'No Image Available';
            imageGallery.innerHTML = '';
        }

        // Update owner information
        document.getElementById('ownerName').textContent = owner.name;
        document.getElementById('ownerEmail').textContent = owner.email;
        document.getElementById('ownerPhone').textContent = owner.phoneNumber || 'Not provided';
        
        // Set owner avatar
        const ownerAvatar = document.getElementById('ownerAvatar');
        if (owner.profilePicture) {
            ownerAvatar.src = owner.profilePicture;
        } else {
            ownerAvatar.src = 'https://via.placeholder.com/100x100?text=U';
        }
        ownerAvatar.alt = owner.name;

        // Setup bookmark button
        const bookmarkBtn = document.getElementById('bookmarkBtn');
        const bookmarkBtnText = document.getElementById('bookmarkBtnText');
        if (item.bookmarked) {
            bookmarkBtnText.textContent = 'Remove Bookmark';
            bookmarkBtn.querySelector('i').classList.replace('far', 'fas');
        }
        
        bookmarkBtn.onclick = async () => {
            try {
                await toggleBookmark(itemId);
                const isNowBookmarked = bookmarkBtnText.textContent === 'Add to Bookmarks';
                bookmarkBtnText.textContent = isNowBookmarked ? 'Remove Bookmark' : 'Add to Bookmarks';
                bookmarkBtn.querySelector('i').classList.replace(isNowBookmarked ? 'far' : 'fas', isNowBookmarked ? 'fas' : 'far');
            } catch (error) {
                showError('Failed to update bookmark');
            }
        };

        // Setup contact owner button
        document.getElementById('contactOwnerBtn').onclick = () => {
            window.location.href = `mailto:${owner.email}?subject=Regarding your item: ${item.title}`;
        };

        // Setup rent button
        document.getElementById('rentBtn').onclick = () => {
            // TODO: Implement rental functionality
            alert('Rental functionality coming soon!');
        };

    } catch (error) {
        showError('Failed to load item details. Please try again later.');
        console.error('Item details loading error:', error);
    } finally {
        toggleLoadingSpinner(false);
    }
}

// Update main image when clicking thumbnails
function updateMainImage(src) {
    document.getElementById('mainImage').src = src;
}

// Show error message
function showError(message) {
    const errorDiv = document.getElementById('errorMessage');
    errorDiv.textContent = message;
    errorDiv.classList.remove('hidden');
    setTimeout(() => errorDiv.classList.add('hidden'), 5000);
}

// Initialize items page
document.addEventListener('DOMContentLoaded', () => {
    // Check authentication
    if (!isAuthenticated()) {
        redirectToLogin();
        return;
    }

    // Load initial items
    loadItems();

    // Add form submit handler
    const newItemForm = document.getElementById('newItemForm');
    if (newItemForm) {
        newItemForm.addEventListener('submit', handleNewItemSubmit);
    }

    // Add photo upload handler
    const photoInput = document.getElementById('photos');
    if (photoInput) {
        photoInput.addEventListener('change', handlePhotoUpload);
    }

    // Add search handler
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        let searchTimeout;
        searchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                currentSearchQuery = e.target.value;
                loadItems(0, currentSearchQuery);
            }, 500);
        });
    }

    // Add infinite scroll
    window.addEventListener('scroll', () => {
        if (
            window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 100 &&
            !isLoading &&
            hasMoreItems
        ) {
            loadItems(currentPage + 1, currentSearchQuery);
        }
    });
});
