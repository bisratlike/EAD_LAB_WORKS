// Profile page functionality
let currentUser = null;

// Load user profile data
async function loadUserProfile() {
    try {
        const response = await fetch(`${API_URL}/users/me`, {
            headers: {
                'Authorization': `Bearer ${getAuthToken()}`
            }
        });

        if (!response.ok) {
            throw new Error('Failed to load profile');
        }

        currentUser = await response.json();
        populateProfileForm(currentUser);
    } catch (error) {
        showError('Failed to load profile. Please try again later.');
        console.error('Profile loading error:', error);
    }
}

// Populate form with user data
function populateProfileForm(userData) {
    document.getElementById('name').value = userData.name || '';
    document.getElementById('email').value = userData.email || '';
    document.getElementById('phoneNumber').value = userData.phoneNumber || '';
    document.getElementById('bio').value = userData.bio || '';
    document.getElementById('trustScore').textContent = userData.trustScore?.toFixed(1) || '0.0';
    
    // Update profile picture
    const profileImage = document.getElementById('profileImage');
    if (userData.profilePicture) {
        profileImage.src = userData.profilePicture;
    }
}

// Handle profile picture change
async function handleProfilePictureChange(event) {
    const file = event.target.files[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
        showError('Please select an image file.');
        return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
        showError('Image size should be less than 5MB.');
        return;
    }

    try {
        // Convert to base64 for preview
        const reader = new FileReader();
        reader.onload = async (e) => {
            const base64Image = e.target.result;
            document.getElementById('profileImage').src = base64Image;
            
            // You would typically upload this to your server/cloud storage
            // and get back a URL. For now, we'll use the base64 string
            currentUser.profilePicture = base64Image;
        };
        reader.readAsDataURL(file);
    } catch (error) {
        showError('Failed to process image. Please try again.');
        console.error('Image processing error:', error);
    }
}

// Update profile
async function updateProfile(profileData) {
    try {
        const response = await fetch(`${API_URL}/users/me`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${getAuthToken()}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(profileData)
        });

        if (!response.ok) {
            throw new Error('Failed to update profile');
        }

        const updatedUser = await response.json();
        currentUser = updatedUser;
        populateProfileForm(updatedUser);
        showSuccess('Profile updated successfully!');
    } catch (error) {
        showError('Failed to update profile. Please try again.');
        console.error('Profile update error:', error);
    }
}

// Handle form submission
async function handleProfileSubmit(event) {
    event.preventDefault();
    
    const form = event.target;
    const submitButton = form.querySelector('button[type="submit"]');
    submitButton.setAttribute('data-original-text', submitButton.innerHTML);
    
    try {
        setLoading(true, submitButton);
        
        const profileData = {
            name: document.getElementById('name').value,
            phoneNumber: document.getElementById('phoneNumber').value ? 
                parseInt(document.getElementById('phoneNumber').value.replace(/\D/g, ''), 10) : null,
            bio: document.getElementById('bio').value,
            profilePicture: currentUser.profilePicture
        };

        // Remove empty optional fields
        Object.keys(profileData).forEach(key => {
            if (!profileData[key] && profileData[key] !== 0) {
                delete profileData[key];
            }
        });

        await updateProfile(profileData);
    } catch (error) {
        showError(error.message || 'Failed to update profile');
    } finally {
        setLoading(false, submitButton);
    }
}

// Initialize profile page
document.addEventListener('DOMContentLoaded', () => {
    // Check authentication
    const userData = localStorage.getItem('user');
    if (!userData) {
        window.location.href = '../login.html';
        throw new Error('User data not found. Please log in again.');
    }

    const user = JSON.parse(userData);
    if (!user || !user.id) {
        localStorage.removeItem('user');
    }

    // Check authentication
    if (!isAuthenticated()) {
        redirectToLogin();
        return;
    }

    // Load user profile
    loadUserProfile();

    // Add form submit handler
    const profileForm = document.getElementById('profile-form');
    if (profileForm) {
        profileForm.addEventListener('submit', handleProfileSubmit);
    }
});
