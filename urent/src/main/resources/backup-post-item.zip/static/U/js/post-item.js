// Constants
const API_BASE_URL = "http://localhost:8090/api";
const ITEMS_ENDPOINT = `${API_BASE_URL}/items`;

// DOM Elements
const postItemForm = document.getElementById("postItemForm");
const imageInput = document.getElementById("images");
const photoPreviewsContainer = document.getElementById("photoPreviewsContainer");
const loadingSpinner = document.getElementById("loadingSpinner");
const errorMessage = document.getElementById("error-message");
const successMessage = document.getElementById("success-message");

// Handle image preview for a single image
imageInput.addEventListener("change", (event) => {
  photoPreviewsContainer.innerHTML = ""; // Clear existing previews
  const file = event.target.files[0]; // Get the first file

  if (file && file.type.startsWith("image/")) {
    const reader = new FileReader();
    reader.onload = (e) => {
      const previewDiv = document.createElement("div");
      previewDiv.className = "relative group";

      const img = document.createElement("img");
      img.src = e.target.result;
      img.className = "w-full h-48 object-cover rounded-lg";

      // Add remove button
      const removeButton = document.createElement("button");
      removeButton.className =
        "absolute top-2 right-2 bg-red-500 text-white rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity";
      removeButton.innerHTML = '<i class="fas fa-times"></i>';
      removeButton.onclick = () => previewDiv.remove();

      previewDiv.appendChild(img);
      previewDiv.appendChild(removeButton);
      photoPreviewsContainer.appendChild(previewDiv);
    };
    reader.readAsDataURL(file);
  } else {
    showError("Please upload a valid image file.");
  }
});

// Handle form submission
postItemForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  // Check if user is logged in
  const token = localStorage.getItem('authToken');
  const userStr = localStorage.getItem('user');

  if (!token || !userStr) {
      showError("You must be logged in to post an item.");
      return;
  }

  // Parse user data
  const user = JSON.parse(userStr);

  // Show loading spinner
  loadingSpinner.style.display = "block";

  try {
      // Get form data
      const formData = new FormData(postItemForm);
      
      // Convert availability to proper enum value
      const availabilityValue = formData.get('availability');
      formData.set('availability', availabilityValue === 'available' ? 'AVAILABLE' : 'RENTED_OUT');
      
      formData.append('image', imageInput.files[0]); // Append the first image
      formData.append('ownerId', user.id); // Include the owner ID from user object
      formData.append('ownerName', user.name); // Include owner name for reference

      // Send request to API
      const response = await fetch(ITEMS_ENDPOINT, {
          method: "POST",
          headers: {
              'Authorization': `Bearer ${token}`
          },
          body: formData,
      });

      // Check if response is OK
      if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      // Get response data
      const responseData = await response.json();

      // Show success message with Tailwind CSS toast
      const toast = document.createElement('div');
      toast.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded shadow-lg z-50 transition-opacity duration-500';
      toast.textContent = "Item posted successfully!";
      document.body.appendChild(toast);

      // Fade out and remove toast after 2 seconds
      setTimeout(() => {
        console.log('Redirecting to items page...');
        window.location.href = 'items.html';
    }, 2000);

  } catch (error) {
      // Show error message
      showError(error.message);
  } finally {
      // Hide loading spinner
      loadingSpinner.style.display = "none";
  }
});

// Helper functions
function showError(message) {
    errorMessage.style.display = "block";
    errorMessage.textContent = message;
    successMessage.style.display = "none";
}

function showSuccess(message) {
    successMessage.style.display = "block";
    successMessage.textContent = message;
    errorMessage.style.display = "none";
}
